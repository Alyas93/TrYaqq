/* ===== ترياق — تحقق رمز التفعيل (بلا إنترنت) =====
   التوقيع ECDSA P-256: المفتاح الخاص عندك وحدك، والتطبيق يحمل المفتاح العام فقط.
   لا يمكن توليد رمز صالح بلا مفتاحك، ولو فُكّ الملف كله.
   يعمل بلا crypto.subtle لأن WebView المحلي (file://) لا يوفّرها. */

/* المفتاح العام — يُستبدل عند بناء النسخة بـ tools/license.js */
var TRQ_PUB = "04bb86a2fb28bea5a72ca960728d0818bdfbe7a2aaed4c24a4c838f066c963706f5c2617e3748fbd8fbbca7692da1a4dadc5d402b712a9edece7c3c14da5d5bc69";

/* ---------- SHA-256 ---------- */
function trqSha256(bytes) {
  const K = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  let h = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const ml = bytes.length * 8;
  const withPad = new Uint8Array((((bytes.length + 9) >> 6) + 1) << 6);
  withPad.set(bytes); withPad[bytes.length] = 0x80;
  new DataView(withPad.buffer).setUint32(withPad.length - 4, ml >>> 0);
  new DataView(withPad.buffer).setUint32(withPad.length - 8, Math.floor(ml / 4294967296));
  const w = new Uint32Array(64), dv = new DataView(withPad.buffer);
  const rr = (x, n) => (x >>> n) | (x << (32 - n));
  for (let i = 0; i < withPad.length; i += 64) {
    for (let t = 0; t < 16; t++) w[t] = dv.getUint32(i + t * 4);
    for (let t = 16; t < 64; t++) {
      const s0 = rr(w[t-15],7) ^ rr(w[t-15],18) ^ (w[t-15] >>> 3);
      const s1 = rr(w[t-2],17) ^ rr(w[t-2],19) ^ (w[t-2] >>> 10);
      w[t] = (w[t-16] + s0 + w[t-7] + s1) >>> 0;
    }
    let [a,b,c,d,e,f,g,hh] = h;
    for (let t = 0; t < 64; t++) {
      const S1 = rr(e,6) ^ rr(e,11) ^ rr(e,25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (hh + S1 + ch + K[t] + w[t]) >>> 0;
      const S0 = rr(a,2) ^ rr(a,13) ^ rr(a,22);
      const mj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + mj) >>> 0;
      hh = g; g = f; f = e; e = (d + t1) >>> 0;
      d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    h = [(h[0]+a)>>>0,(h[1]+b)>>>0,(h[2]+c)>>>0,(h[3]+d)>>>0,
         (h[4]+e)>>>0,(h[5]+f)>>>0,(h[6]+g)>>>0,(h[7]+hh)>>>0];
  }
  const out = new Uint8Array(32);
  h.forEach((x, i) => { out[i*4]=x>>>24; out[i*4+1]=(x>>>16)&255; out[i*4+2]=(x>>>8)&255; out[i*4+3]=x&255; });
  return out;
}
const trqHex = b => Array.from(b).map(x => x.toString(16).padStart(2, "0")).join("");
function trqBytes(str) {
  const out = [];
  for (const ch of String(str)) {
    let c = ch.codePointAt(0);
    if (c < 128) out.push(c);
    else if (c < 2048) out.push(192 | (c >> 6), 128 | (c & 63));
    else if (c < 65536) out.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63));
    else out.push(240 | (c >> 18), 128 | ((c >> 12) & 63), 128 | ((c >> 6) & 63), 128 | (c & 63));
  }
  return new Uint8Array(out);
}
function trqB64u(str) {                       /* base64url → bytes */
  let s = String(str).replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  const bin = atob(s), out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}
function trqB64uStr(bytes) {
  let bin = ""; bytes.forEach(b => bin += String.fromCharCode(b));
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/* ---------- ECDSA على منحنى P-256 ---------- */
const P256 = {
  p: BigInt("0xffffffff00000001000000000000000000000000ffffffffffffffffffffffff"),
  n: BigInt("0xffffffff00000000ffffffffffffffffbce6faada7179e84f3b9cac2fc632551"),
  a: BigInt("0xffffffff00000001000000000000000000000000fffffffffffffffffffffffc"),
  gx: BigInt("0x6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296"),
  gy: BigInt("0x4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5")
};
const mod = (x, m) => ((x % m) + m) % m;
function modPow(b, e, m) {
  let r = 1n; b = mod(b, m);
  while (e > 0n) { if (e & 1n) r = (r * b) % m; b = (b * b) % m; e >>= 1n; }
  return r;
}
const modInv = (x, m) => modPow(mod(x, m), m - 2n, m);
/* نقاط بإحداثيات جاكوبية لتفادي القسمة في كل خطوة */
function jDouble(P) {
  const p = P256.p, [X, Y, Z] = P;
  if (Y === 0n) return [0n, 0n, 0n];
  const A = (Y * Y) % p;
  const B = (4n * X * A) % p;
  const C = (8n * A * A) % p;
  const Z2 = (Z * Z) % p;
  const D = (3n * (X - Z2) * (X + Z2)) % p;      /* a = -3 */
  const X3 = mod(D * D - 2n * B, p);
  const Y3 = mod(D * (B - X3) - C, p);
  const Z3 = mod(2n * Y * Z, p);
  return [X3, Y3, Z3];
}
function jAdd(P, Q) {
  const p = P256.p;
  if (P[2] === 0n) return Q;
  if (Q[2] === 0n) return P;
  const [X1, Y1, Z1] = P, [X2, Y2, Z2] = Q;
  const Z1s = (Z1 * Z1) % p, Z2s = (Z2 * Z2) % p;
  const U1 = (X1 * Z2s) % p, U2 = (X2 * Z1s) % p;
  const S1 = (Y1 * Z2s * Z2) % p, S2 = (Y2 * Z1s * Z1) % p;
  const H = mod(U2 - U1, p), R = mod(S2 - S1, p);
  if (H === 0n) return R === 0n ? jDouble(P) : [0n, 0n, 0n];
  const H2 = (H * H) % p, H3 = (H2 * H) % p;
  const X3 = mod(R * R - H3 - 2n * U1 * H2, p);
  const Y3 = mod(R * (U1 * H2 - X3) - S1 * H3, p);
  const Z3 = mod(H * Z1 * Z2, p);
  return [X3, Y3, Z3];
}
function jMul(k, P) {
  let R = [0n, 0n, 0n], Q = P;
  while (k > 0n) { if (k & 1n) R = jAdd(R, Q); Q = jDouble(Q); k >>= 1n; }
  return R;
}
function jAffineX(P) {
  if (P[2] === 0n) return null;
  const zi = modInv(P[2], P256.p);
  return mod(P[0] * zi % P256.p * zi, P256.p);
}
/* msg: Uint8Array · sig: 64 بايت (r||s) · pub: نقطة hex غير مضغوطة */
function p256Verify(msg, sig, pubHex) {
  try {
    if (!sig || sig.length !== 64) return false;
    const n = P256.n;
    const r = BigInt("0x" + trqHex(sig.slice(0, 32)));
    const s = BigInt("0x" + trqHex(sig.slice(32)));
    if (r <= 0n || r >= n || s <= 0n || s >= n) return false;
    const qx = BigInt("0x" + pubHex.slice(2, 66));
    const qy = BigInt("0x" + pubHex.slice(66, 130));
    const z = BigInt("0x" + trqHex(trqSha256(msg))) % n;
    const w = modInv(s, n);
    const R = jAdd(jMul(mod(z * w, n), [P256.gx, P256.gy, 1n]),
                   jMul(mod(r * w, n), [qx, qy, 1n]));
    const x = jAffineX(R);
    return x !== null && mod(x, n) === r;
  } catch (e) { return false; }
}

/* ---------- الرمز والجهاز ---------- */
/* بصمة الجهاز: تُشتق من معرّف محلي ثابت، وتُعرض للزبون ليرسلها لك */
function trqDeviceCode(seed) {
  const h = trqHex(trqSha256(trqBytes("tiryaq|" + seed))).slice(0, 12).toUpperCase();
  return h.slice(0, 4) + "-" + h.slice(4, 8) + "-" + h.slice(8, 12);
}
/* الرمز: TRQ.<payload>.<signature> */
function trqCheckLicense(code, deviceCode, todayStr) {
  const parts = String(code || "").trim().split(".");
  if (parts.length !== 3 || parts[0] !== "TRQ") return { ok: false, why: "صيغة الرمز غير صحيحة" };
  let pay;
  try { pay = JSON.parse(new TextDecoder().decode(trqB64u(parts[1]))); }
  catch (e) { return { ok: false, why: "تعذّرت قراءة الرمز" }; }
  if (!p256Verify(trqBytes(parts[1]), trqB64u(parts[2]), TRQ_PUB))
    return { ok: false, why: "الرمز غير صالح — لم يصدر من المزوّد" };
  if (pay.d && pay.d !== "*" && pay.d !== deviceCode)
    return { ok: false, why: "هذا الرمز مسجّل لجهاز آخر" };
  const today = todayStr || new Date().toISOString().slice(0, 10);
  if (pay.u && pay.u !== "*" && today > pay.u)
    return { ok: false, why: "انتهى الاشتراك بتاريخ " + pay.u, expired: true, pay: pay };
  return { ok: true, pay: pay };
}

if (typeof module !== "undefined") module.exports = {
  trqSha256, trqHex, trqBytes, trqB64u, trqB64uStr, p256Verify, trqDeviceCode, trqCheckLicense,
  setPub: k => { TRQ_PUB = k; }
};
